export interface BlogPost {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  category: 'Quran' | 'Hadith' | 'Fiqh' | 'History' | 'Lifestyle' | 'Family' | 'Comparative';
  date: string;
  readTime: string;
  emoji: string;
}

export const blogPosts: BlogPost[] = [
  // Quran (10 posts)
  { id: 1, slug: "miracle-surah-al-fatihah", title: "The Miracle of Surah Al-Fatihah", excerpt: "Explore the profound meanings and spiritual significance of the Opening Chapter of the Quran, known as the Mother of the Book.", category: "Quran", date: "2024-01-15", readTime: "25 min", emoji: "📖" },
  { id: 2, slug: "stories-of-the-prophets-quran", title: "Understanding the Stories of the Prophets in the Quran", excerpt: "Discover the timeless lessons from the narratives of prophets in the Quran and their relevance to modern life.", category: "Quran", date: "2024-01-20", readTime: "30 min", emoji: "📖" },
  { id: 3, slug: "beauty-of-quranic-recitation", title: "The Beauty of Quranic Recitation (Tajweed)", excerpt: "Learn about the art of Tajweed and how proper recitation enhances your spiritual connection with the Quran.", category: "Quran", date: "2024-02-01", readTime: "20 min", emoji: "📖" },
  { id: 4, slug: "tafsir-unlocking-deeper-meanings", title: "Tafsir: Unlocking Deeper Meanings of the Quran", excerpt: "An introduction to Quranic exegesis and how scholars interpret the verses for practical guidance.", category: "Quran", date: "2024-02-10", readTime: "25 min", emoji: "📖" },
  { id: 5, slug: "scientific-miracles-quran", title: "The Scientific Miracles in the Quran", excerpt: "Explore the remarkable scientific references in the Quran that were discovered centuries later.", category: "Quran", date: "2024-02-18", readTime: "35 min", emoji: "📖" },
  { id: 6, slug: "memorizing-quran-hifz-guide", title: "Memorizing the Quran: A Complete Hifz Guide", excerpt: "Tips and techniques for Hifz and the immense blessings of becoming a Hafiz.", category: "Quran", date: "2024-02-25", readTime: "30 min", emoji: "📖" },
  { id: 7, slug: "preservation-of-quran", title: "The Preservation of the Quran Through History", excerpt: "How the Quran has been perfectly preserved from the time of Prophet Muhammad (PBUH) to today.", category: "Quran", date: "2024-03-05", readTime: "25 min", emoji: "📖" },
  { id: 8, slug: "themes-of-mercy-in-quran", title: "Themes of Mercy in the Quran", excerpt: "Understanding Allah's infinite mercy as described throughout the Holy Quran.", category: "Quran", date: "2024-03-12", readTime: "20 min", emoji: "📖" },
  { id: 9, slug: "quran-environmental-stewardship", title: "The Quran's Guidance on Environmental Stewardship", excerpt: "Discover the ecological teachings in the Quran and our responsibility as stewards of the Earth.", category: "Quran", date: "2024-03-20", readTime: "22 min", emoji: "📖" },
  { id: 10, slug: "understanding-juz-amma", title: "Understanding Juz Amma: The Final Section", excerpt: "A comprehensive guide to the most frequently recited section of the Quran.", category: "Quran", date: "2024-03-28", readTime: "35 min", emoji: "📖" },
  
  // Hadith (10 posts)
  { id: 11, slug: "importance-of-authentic-hadith", title: "The Importance of Authentic Hadith", excerpt: "Understanding the science of Hadith authentication and its role in Islamic jurisprudence.", category: "Hadith", date: "2024-01-18", readTime: "25 min", emoji: "📜" },
  { id: 12, slug: "forty-hadith-nawawi", title: "40 Hadith Nawawi: Essential Islamic Teachings", excerpt: "A study of Imam Nawawi's collection of forty hadith that encompass Islamic teachings.", category: "Hadith", date: "2024-01-25", readTime: "45 min", emoji: "📜" },
  { id: 13, slug: "hadith-on-good-character", title: "Hadith on Good Character (Akhlaq)", excerpt: "Prophetic teachings on developing excellent character and moral conduct.", category: "Hadith", date: "2024-02-05", readTime: "20 min", emoji: "📜" },
  { id: 14, slug: "prophet-teachings-on-health", title: "The Prophet's (PBUH) Teachings on Health", excerpt: "Discover the health recommendations found in authentic hadith traditions.", category: "Hadith", date: "2024-02-12", readTime: "22 min", emoji: "📜" },
  { id: 15, slug: "virtues-of-dhikr-hadith", title: "Hadith on the Virtues of Dhikr", excerpt: "Learn about the remembrance of Allah through Prophetic traditions.", category: "Hadith", date: "2024-02-20", readTime: "18 min", emoji: "📜" },
  { id: 16, slug: "chain-of-narrators-isnad", title: "Understanding Chain of Narrators (Isnad)", excerpt: "How scholars verify the authenticity of hadith through careful chain analysis.", category: "Hadith", date: "2024-02-28", readTime: "25 min", emoji: "📜" },
  { id: 17, slug: "hadith-on-family-relations", title: "Hadith on Family Relations", excerpt: "Prophetic guidance on maintaining strong family bonds and relationships.", category: "Hadith", date: "2024-03-08", readTime: "20 min", emoji: "📜" },
  { id: 18, slug: "collection-of-sahih-bukhari", title: "The Collection of Sahih Bukhari", excerpt: "Understanding the most authentic book after the Quran and its compilation.", category: "Hadith", date: "2024-03-15", readTime: "30 min", emoji: "📜" },
  { id: 19, slug: "hadith-on-charity-generosity", title: "Hadith on Charity and Generosity", excerpt: "Prophetic teachings on giving and the blessings of charity.", category: "Hadith", date: "2024-03-22", readTime: "18 min", emoji: "📜" },
  { id: 20, slug: "prophets-daily-supplications", title: "The Prophet's (PBUH) Daily Supplications", excerpt: "Morning and evening adhkar from authentic prophetic traditions.", category: "Hadith", date: "2024-03-30", readTime: "25 min", emoji: "📜" },
  
  // Fiqh (10 posts)
  { id: 21, slug: "schools-of-islamic-jurisprudence", title: "Understanding the Schools of Islamic Jurisprudence", excerpt: "An introduction to the four major madhabs and their methodologies.", category: "Fiqh", date: "2024-01-22", readTime: "35 min", emoji: "⚖️" },
  { id: 22, slug: "islamic-finance-principles", title: "The Principles of Islamic Finance", excerpt: "Understanding halal investment and the prohibition of interest (riba).", category: "Fiqh", date: "2024-01-28", readTime: "30 min", emoji: "⚖️" },
  { id: 23, slug: "purification-and-wudu-guide", title: "Purification and Wudu: A Comprehensive Guide", excerpt: "Detailed guidance on ritual purification according to Islamic law.", category: "Fiqh", date: "2024-02-03", readTime: "25 min", emoji: "⚖️" },
  { id: 24, slug: "fiqh-of-fasting", title: "The Fiqh of Fasting: Beyond the Basics", excerpt: "Advanced rulings on fasting, including voluntary fasts and make-up days.", category: "Fiqh", date: "2024-02-15", readTime: "30 min", emoji: "⚖️" },
  { id: 25, slug: "understanding-zakat-calculation", title: "Understanding Zakat Calculation", excerpt: "A practical guide to calculating and distributing your zakat correctly.", category: "Fiqh", date: "2024-02-22", readTime: "28 min", emoji: "⚖️" },
  { id: 26, slug: "fiqh-of-hajj-umrah", title: "The Fiqh of Hajj and Umrah", excerpt: "Essential rulings for pilgrims undertaking the sacred journey.", category: "Fiqh", date: "2024-03-01", readTime: "40 min", emoji: "⚖️" },
  { id: 27, slug: "islamic-rulings-medical-ethics", title: "Islamic Rulings on Medical Ethics", excerpt: "Understanding fiqh perspectives on modern medical issues.", category: "Fiqh", date: "2024-03-10", readTime: "25 min", emoji: "⚖️" },
  { id: 28, slug: "principles-of-halal-haram", title: "The Principles of Halal and Haram", excerpt: "Understanding the methodology for determining what is permissible in Islam.", category: "Fiqh", date: "2024-03-18", readTime: "22 min", emoji: "⚖️" },
  { id: 29, slug: "fiqh-of-marriage-family", title: "Fiqh of Marriage and Family Life", excerpt: "Islamic rulings on marriage contracts, rights, and responsibilities.", category: "Fiqh", date: "2024-03-25", readTime: "30 min", emoji: "⚖️" },
  { id: 30, slug: "contemporary-fiqh-issues", title: "Contemporary Fiqh Issues", excerpt: "How scholars address modern challenges using Islamic legal principles.", category: "Fiqh", date: "2024-04-01", readTime: "28 min", emoji: "⚖️" },
  
  // History (10 posts)
  { id: 31, slug: "life-of-prophet-muhammad", title: "The Life of Prophet Muhammad (PBUH)", excerpt: "A comprehensive biography of the final messenger and his blessed life.", category: "History", date: "2024-01-12", readTime: "45 min", emoji: "🏛️" },
  { id: 32, slug: "four-rightly-guided-caliphs", title: "The Four Rightly Guided Caliphs", excerpt: "Understanding the golden era of Islamic leadership under the Khulafa Rashidun.", category: "History", date: "2024-01-30", readTime: "40 min", emoji: "🏛️" },
  { id: 33, slug: "spread-of-islam-history", title: "The Spread of Islam: A Historical Perspective", excerpt: "How Islam spread across continents through trade, scholarship, and example.", category: "History", date: "2024-02-08", readTime: "35 min", emoji: "🏛️" },
  { id: 34, slug: "islamic-golden-age", title: "Islamic Golden Age: Science and Philosophy", excerpt: "The remarkable contributions of Muslim scholars to human civilization.", category: "History", date: "2024-02-16", readTime: "30 min", emoji: "🏛️" },
  { id: 35, slug: "history-of-the-kaaba", title: "The History of the Kaaba", excerpt: "From Prophet Ibrahim to the present day: the sacred sanctuary's story.", category: "History", date: "2024-02-24", readTime: "25 min", emoji: "🏛️" },
  { id: 36, slug: "great-muslim-scholars", title: "Great Muslim Scholars of the Past", excerpt: "Profiles of influential scholars who shaped Islamic intellectual tradition.", category: "History", date: "2024-03-04", readTime: "35 min", emoji: "🏛️" },
  { id: 37, slug: "battle-of-badr", title: "The Battle of Badr: A Turning Point", excerpt: "The first major battle in Islamic history and its profound significance.", category: "History", date: "2024-03-13", readTime: "28 min", emoji: "🏛️" },
  { id: 38, slug: "islam-in-scotland", title: "Islam in Scotland: A Brief History", excerpt: "The story of Muslim communities in Scotland and their contributions.", category: "History", date: "2024-03-21", readTime: "20 min", emoji: "🏛️" },
  { id: 39, slug: "treaty-of-hudaybiyyah", title: "The Treaty of Hudaybiyyah", excerpt: "Lessons in diplomacy and patience from this pivotal prophetic event.", category: "History", date: "2024-03-29", readTime: "22 min", emoji: "🏛️" },
  { id: 40, slug: "muslim-contributions-mathematics", title: "Muslim Contributions to Mathematics", excerpt: "How Muslim mathematicians advanced algebra, algorithms, and more.", category: "History", date: "2024-04-05", readTime: "25 min", emoji: "🏛️" },
  
  // Lifestyle (10 posts)
  { id: 41, slug: "islamic-time-management", title: "Finding Balance: Islamic Time Management", excerpt: "How to organize your day around prayers and maintain productivity.", category: "Lifestyle", date: "2024-01-16", readTime: "18 min", emoji: "🌟" },
  { id: 42, slug: "islamic-etiquette-digital-age", title: "Islamic Etiquette in the Digital Age", excerpt: "Guidelines for Muslims navigating social media and online spaces.", category: "Lifestyle", date: "2024-01-24", readTime: "20 min", emoji: "🌟" },
  { id: 43, slug: "islamic-approach-mental-health", title: "The Islamic Approach to Mental Health", excerpt: "Understanding emotional wellbeing through the lens of Islamic teachings.", category: "Lifestyle", date: "2024-02-02", readTime: "25 min", emoji: "🌟" },
  { id: 44, slug: "halal-eating-guide", title: "Halal Eating: Beyond the Label", excerpt: "Understanding halal food standards and making informed choices.", category: "Lifestyle", date: "2024-02-11", readTime: "18 min", emoji: "🌟" },
  { id: 45, slug: "islamic-dress-code", title: "Islamic Dress Code: Modesty and Dignity", excerpt: "Understanding the wisdom behind Islamic guidelines on dress.", category: "Lifestyle", date: "2024-02-19", readTime: "22 min", emoji: "🌟" },
  { id: 46, slug: "sustainable-living-islamic-perspective", title: "Sustainable Living: An Islamic Perspective", excerpt: "How Islamic teachings encourage environmental responsibility.", category: "Lifestyle", date: "2024-02-26", readTime: "20 min", emoji: "🌟" },
  { id: 47, slug: "prophets-daily-routine", title: "The Prophet's (PBUH) Daily Routine", excerpt: "Learning from the blessed daily habits of the Prophet Muhammad (PBUH).", category: "Lifestyle", date: "2024-03-06", readTime: "18 min", emoji: "🌟" },
  { id: 48, slug: "islamic-greetings-meanings", title: "Islamic Greetings and Their Meanings", excerpt: "The significance of salaam and other Islamic expressions.", category: "Lifestyle", date: "2024-03-14", readTime: "15 min", emoji: "🌟" },
  { id: 49, slug: "work-ethics-in-islam", title: "Work Ethics in Islam", excerpt: "Islamic principles for professional conduct and workplace behavior.", category: "Lifestyle", date: "2024-03-23", readTime: "20 min", emoji: "🌟" },
  { id: 50, slug: "gratitude-in-islam", title: "Gratitude in Islam: A Way of Life", excerpt: "Cultivating shukr in daily life for spiritual and mental benefits.", category: "Lifestyle", date: "2024-03-31", readTime: "18 min", emoji: "🌟" },
  
  // Family (5 posts)
  { id: 51, slug: "raising-children-in-the-west", title: "Raising Children in the West", excerpt: "Practical advice for Muslim parents navigating cultural challenges.", category: "Family", date: "2024-01-19", readTime: "25 min", emoji: "👨‍👩‍👧‍👦" },
  { id: 52, slug: "rights-of-parents-in-islam", title: "The Rights of Parents in Islam", excerpt: "Understanding the sacred duty of honoring and caring for parents.", category: "Family", date: "2024-01-31", readTime: "20 min", emoji: "👨‍👩‍👧‍👦" },
  { id: 53, slug: "building-strong-islamic-home", title: "Building a Strong Islamic Home", excerpt: "Creating an environment of faith, love, and learning in your household.", category: "Family", date: "2024-02-07", readTime: "22 min", emoji: "👨‍👩‍👧‍👦" },
  { id: 54, slug: "marriage-in-islam-guide", title: "Marriage in Islam: Rights and Responsibilities", excerpt: "Understanding the Islamic framework for a blessed marital relationship.", category: "Family", date: "2024-02-14", readTime: "28 min", emoji: "👨‍👩‍👧‍👦" },
  { id: 55, slug: "teaching-quran-to-children", title: "Teaching Quran to Children", excerpt: "Effective methods for introducing the Quran to young learners.", category: "Family", date: "2024-02-21", readTime: "18 min", emoji: "👨‍👩‍👧‍👦" },
  
  // Comparative (5 posts)
  { id: 56, slug: "islam-and-christianity-common-ground", title: "Common Ground: Islam and Christianity", excerpt: "Exploring shared beliefs and fostering interfaith understanding.", category: "Comparative", date: "2024-01-21", readTime: "30 min", emoji: "🤝" },
  { id: 57, slug: "prophets-in-islam-other-faiths", title: "Prophets in Islam and Other Faiths", excerpt: "Comparing the role and significance of prophets across Abrahamic religions.", category: "Comparative", date: "2024-02-04", readTime: "25 min", emoji: "🤝" },
  { id: 58, slug: "understanding-religious-pluralism", title: "Understanding Religious Pluralism", excerpt: "The Islamic perspective on religious diversity and coexistence.", category: "Comparative", date: "2024-02-13", readTime: "22 min", emoji: "🤝" },
  { id: 59, slug: "common-misconceptions-about-islam", title: "Common Misconceptions About Islam", excerpt: "Addressing frequently misunderstood aspects of Islamic teachings.", category: "Comparative", date: "2024-02-23", readTime: "28 min", emoji: "🤝" },
  { id: 60, slug: "concept-of-god-major-religions", title: "The Concept of God in Major Religions", excerpt: "Comparing the understanding of the Divine across different faith traditions.", category: "Comparative", date: "2024-03-03", readTime: "30 min", emoji: "🤝" }
];

export const categories = [
  { id: 'all', label: 'All Topics', icon: '📚' },
  { id: 'Quran', label: 'Quran', icon: '📖' },
  { id: 'Hadith', label: 'Hadith', icon: '📜' },
  { id: 'Fiqh', label: 'Fiqh', icon: '⚖️' },
  { id: 'History', label: 'History', icon: '🏛️' },
  { id: 'Lifestyle', label: 'Lifestyle', icon: '🌟' },
  { id: 'Family', label: 'Family', icon: '👨‍👩‍👧‍👦' },
  { id: 'Comparative', label: 'Comparative', icon: '🤝' }
] as const;
