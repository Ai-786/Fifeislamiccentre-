import * as adhan from 'adhan';

// Glenrothes, Fife coordinates
export const GLENROTHES_COORDINATES = {
  latitude: 56.1937,
  longitude: -3.1588
};

// Calculation methods mapping
export type CalculationMethodType = 'MWL' | 'Karachi' | 'ISNA' | 'UmmAlQura' | 'Egyptian' | 'MoonsightingCommittee';

export interface CalculationMethodOption {
  value: CalculationMethodType;
  label: string;
}

export const CALCULATION_METHODS: CalculationMethodOption[] = [
  { value: 'MWL', label: 'Muslim World League' },
  { value: 'Karachi', label: 'University of Islamic Sciences, Karachi' },
  { value: 'ISNA', label: 'Islamic Society of North America' },
  { value: 'UmmAlQura', label: 'Umm Al-Qura University, Makkah' },
  { value: 'Egyptian', label: 'Egyptian General Authority of Survey' },
  { value: 'MoonsightingCommittee', label: 'Moonsighting Committee' }
];

// Get calculation parameters based on method
export function getCalculationParams(method: CalculationMethodType): adhan.CalculationParameters {
  switch (method) {
    case 'MWL':
      return adhan.CalculationMethod.MuslimWorldLeague();
    case 'Karachi':
      return adhan.CalculationMethod.Karachi();
    case 'ISNA':
      return adhan.CalculationMethod.NorthAmerica();
    case 'UmmAlQura':
      return adhan.CalculationMethod.UmmAlQura();
    case 'Egyptian':
      return adhan.CalculationMethod.Egyptian();
    case 'MoonsightingCommittee':
      return adhan.CalculationMethod.MoonsightingCommittee();
    default:
      return adhan.CalculationMethod.MuslimWorldLeague();
  }
}

// School of thought for Asr calculation
export type SchoolOfThoughtType = 'Shafi' | 'Hanafi';

export interface SchoolOfThoughtOption {
  value: SchoolOfThoughtType;
  label: string;
}

export const SCHOOLS_OF_THOUGHT: SchoolOfThoughtOption[] = [
  { value: 'Shafi', label: "Shafi'i (Standard)" },
  { value: 'Hanafi', label: "Hanafi" }
];

// Prayer times interface
export interface PrayerTimesResult {
  fajr: Date;
  sunrise: Date;
  dhuhr: Date;
  asr: Date;
  maghrib: Date;
  isha: Date;
}

// Calculate prayer times for a given date
export function calculatePrayerTimes(
  date: Date,
  calculationMethod: CalculationMethodType = 'MWL',
  schoolOfThought: SchoolOfThoughtType = 'Shafi'
): PrayerTimesResult {
  const coordinates = new adhan.Coordinates(GLENROTHES_COORDINATES.latitude, GLENROTHES_COORDINATES.longitude);
  const params = getCalculationParams(calculationMethod);
  
  // Set Asr calculation based on school of thought
  if (schoolOfThought === 'Hanafi') {
    params.madhab = adhan.Madhab.Hanafi;
  } else {
    params.madhab = adhan.Madhab.Shafi;
  }
  
  const prayerTimes = new adhan.PrayerTimes(coordinates, date, params);
  
  return {
    fajr: prayerTimes.fajr,
    sunrise: prayerTimes.sunrise,
    dhuhr: prayerTimes.dhuhr,
    asr: prayerTimes.asr,
    maghrib: prayerTimes.maghrib,
    isha: prayerTimes.isha
  };
}

// Get next prayer
export interface NextPrayer {
  name: string;
  time: Date;
  currentPrayer: string;
}

export function getNextPrayer(
  date: Date,
  calculationMethod: CalculationMethodType = 'MWL',
  schoolOfThought: SchoolOfThoughtType = 'Shafi'
): NextPrayer {
  const coordinates = new adhan.Coordinates(GLENROTHES_COORDINATES.latitude, GLENROTHES_COORDINATES.longitude);
  const params = getCalculationParams(calculationMethod);
  
  if (schoolOfThought === 'Hanafi') {
    params.madhab = adhan.Madhab.Hanafi;
  } else {
    params.madhab = adhan.Madhab.Shafi;
  }
  
  const prayerTimes = new adhan.PrayerTimes(coordinates, date, params);
  const nextPrayer = prayerTimes.nextPrayer();
  const currentPrayer = prayerTimes.currentPrayer();
  
  const prayerNames: Record<string, string> = {
    'Fajr': 'Fajr',
    'Sunrise': 'Sunrise',
    'Dhuhr': 'Dhuhr',
    'Asr': 'Asr',
    'Maghrib': 'Maghrib',
    'Isha': 'Isha',
    'None': 'Fajr'
  };
  
  const nextPrayerTime = prayerTimes.timeForPrayer(nextPrayer);
  
  return {
    name: prayerNames[nextPrayer] || 'Fajr',
    time: nextPrayerTime || prayerTimes.fajr,
    currentPrayer: prayerNames[currentPrayer] || 'None'
  };
}

// Format time to 24-hour format (HH:MM)
export function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: 'Europe/London'
  });
}

// Format time to 12-hour format with AM/PM
export function formatTime12Hour(date: Date): string {
  return date.toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
    timeZone: 'Europe/London'
  });
}

// Get prayer times for an entire month
export interface DailyPrayerTimes {
  date: Date;
  day: number;
  dayName: string;
  fajr: string;
  sunrise: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
}

export function getMonthlyPrayerTimes(
  year: number,
  month: number,
  calculationMethod: CalculationMethodType = 'MWL',
  schoolOfThought: SchoolOfThoughtType = 'Shafi'
): DailyPrayerTimes[] {
  const days: DailyPrayerTimes[] = [];
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(year, month, day);
    const times = calculatePrayerTimes(date, calculationMethod, schoolOfThought);
    
    days.push({
      date,
      day,
      dayName: dayNames[date.getDay()],
      fajr: formatTime(times.fajr),
      sunrise: formatTime(times.sunrise),
      dhuhr: formatTime(times.dhuhr),
      asr: formatTime(times.asr),
      maghrib: formatTime(times.maghrib),
      isha: formatTime(times.isha)
    });
  }
  
  return days;
}

// Get month name
export function getMonthName(month: number): string {
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return monthNames[month];
}

// Calculate time remaining until next prayer
export interface CountdownTime {
  hours: number;
  minutes: number;
  seconds: number;
  totalSeconds: number;
}

export function getCountdown(targetTime: Date, currentTime: Date): CountdownTime {
  let diff = targetTime.getTime() - currentTime.getTime();
  
  // If the time is in the past, it might be tomorrow's prayer
  if (diff < 0) {
    // Add 24 hours to get to tomorrow
    diff += 24 * 60 * 60 * 1000;
  }
  
  const totalSeconds = Math.floor(diff / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  
  return { hours, minutes, seconds, totalSeconds };
}

// Get Islamic date (approximation based on calculation)
export function getIslamicDate(date: Date): { day: number; month: string; year: number } {
  // This is an approximation - for accurate Islamic dates, use a proper library
  // The Islamic calendar is lunar, so dates shift by about 11 days each year
  const knownHijriDate = new Date('2024-07-07'); // 1 Muharram 1446
  const msPerDay = 86400000;
  const lunarYearInDays = 354.36667;
  
  const diffMs = date.getTime() - knownHijriDate.getTime();
  const diffDays = Math.floor(diffMs / msPerDay);
  
  const hijriYear = 1446 + Math.floor(diffDays / lunarYearInDays);
  const daysInCurrentYear = diffDays % Math.floor(lunarYearInDays);
  
  const hijriMonths = [
    'Muharram', 'Safar', 'Rabi al-Awwal', 'Rabi al-Thani',
    'Jumada al-Awwal', 'Jumada al-Thani', 'Rajab', 'Sha\'ban',
    'Ramadan', 'Shawwal', 'Dhu al-Qi\'dah', 'Dhu al-Hijjah'
  ];
  
  const daysPerMonth = [30, 29, 30, 29, 30, 29, 30, 29, 30, 29, 30, 29]; // Approximate
  
  let dayCount = 0;
  let currentMonth = 0;
  
  for (let i = 0; i < 12; i++) {
    if (daysInCurrentYear < dayCount + daysPerMonth[i]) {
      currentMonth = i;
      break;
    }
    dayCount += daysPerMonth[i];
  }
  
  const hijriDay = daysInCurrentYear - dayCount + 1;
  
  return {
    day: hijriDay,
    month: hijriMonths[currentMonth],
    year: hijriYear
  };
}

// Jamaat times (congregation times) - typically 15-30 minutes after adhan
// These are the mosque's fixed jamaat times
export function getJamaatTimes(prayerTimes: PrayerTimesResult): {
  fajr: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
} {
  // Add fixed minutes for jamaat times
  const addMinutes = (date: Date, minutes: number): Date => {
    return new Date(date.getTime() + minutes * 60000);
  };
  
  // Jamaat times are typically fixed or have a standard delay
  // These are approximate - actual times may vary by mosque
  return {
    fajr: formatTime(addMinutes(prayerTimes.fajr, 20)),
    dhuhr: formatTime(addMinutes(prayerTimes.dhuhr, 15)),
    asr: formatTime(addMinutes(prayerTimes.asr, 15)),
    maghrib: formatTime(addMinutes(prayerTimes.maghrib, 5)),
    isha: formatTime(addMinutes(prayerTimes.isha, 15))
  };
}
