'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  ArrowLeft,
  Clock,
  Calendar,
  User,
  Copy,
  Check,
  ChevronRight,
  BookOpen,
  MessageCircle,
  Facebook,
  Twitter,
  Linkedin,
  Mail
} from 'lucide-react';
import { allBlogPosts } from '@/lib/data/blogContent';

// Table of Contents Component
function TableOfContents({ sections }: { sections: { title: string }[] }) {
  const [activeSection, setActiveSection] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const sectionElements = document.querySelectorAll('[data-section]');
      const scrollPosition = window.scrollY + 200;

      sectionElements.forEach((section, index) => {
        const rect = section.getBoundingClientRect();
        const top = rect.top + window.scrollY;
        if (scrollPosition >= top && scrollPosition < top + rect.height) {
          setActiveSection(index);
        }
      });
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (index: number) => {
    const element = document.querySelector(`[data-section="${index}"]`);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="sticky top-24 bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
      <h3 className="font-bold text-[#0d5c4b] mb-4 flex items-center gap-2">
        <BookOpen className="w-5 h-5" />
        Table of Contents
      </h3>
      <nav className="space-y-2">
        {sections.map((section, index) => (
          <button
            key={index}
            onClick={() => scrollToSection(index)}
            className={`w-full text-left text-sm py-2 px-3 rounded-lg transition-all ${
              activeSection === index
                ? 'bg-[#0d5c4b] text-white'
                : 'text-[#334155] hover:bg-[#f0fdf4]'
            }`}
          >
            <span className="mr-2">{index + 1}.</span>
            {section.title}
          </button>
        ))}
      </nav>
    </div>
  );
}

// FAQ Accordion Component
function FAQSection({ faqs }: { faqs: { question: string; answer: string }[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-serif font-bold text-[#0d5c4b] mb-6 flex items-center gap-2">
        <MessageCircle className="w-6 h-6 text-[#c9a227]" />
        Frequently Asked Questions
      </h2>
      {faqs.map((faq, index) => (
        <div
          key={index}
          className="border border-gray-200 rounded-xl overflow-hidden bg-white shadow-sm"
        >
          <button
            onClick={() => setOpenIndex(openIndex === index ? null : index)}
            className="w-full text-left p-5 flex items-center justify-between hover:bg-[#f0fdf4] transition-colors"
          >
            <span className="font-semibold text-[#0d5c4b] pr-4">{faq.question}</span>
            <ChevronRight
              className={`w-5 h-5 text-[#c9a227] transition-transform flex-shrink-0 ${
                openIndex === index ? 'rotate-90' : ''
              }`}
            />
          </button>
          {openIndex === index && (
            <div className="px-5 pb-5 text-[#334155] leading-relaxed border-t border-gray-100">
              <p className="pt-4">{faq.answer}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// Step by Step Guide Component
function StepByStepSection({ guide }: { guide: {
  title: string;
  introduction: string;
  steps: {
    step: number;
    title: string;
    content: string;
    tips?: string[];
  }[];
}}) {
  return (
    <div className="bg-gradient-to-br from-[#f0fdf4] to-white rounded-2xl p-8 border border-[#0d5c4b]/10">
      <h2 className="text-2xl font-serif font-bold text-[#0d5c4b] mb-4 flex items-center gap-2">
        <span className="text-3xl">📋</span>
        {guide.title}
      </h2>
      <p className="text-[#334155] mb-8 leading-relaxed">{guide.introduction}</p>
      
      <div className="space-y-6">
        {guide.steps.map((step) => (
          <div
            key={step.step}
            className="flex gap-4 bg-white rounded-xl p-6 shadow-sm border border-gray-100"
          >
            <div className="flex-shrink-0">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] text-white flex items-center justify-center font-bold">
                {step.step}
              </div>
            </div>
            <div className="flex-grow">
              <h3 className="font-semibold text-[#0d5c4b] mb-2">{step.title}</h3>
              <p className="text-[#334155] leading-relaxed mb-3">{step.content}</p>
              {step.tips && step.tips.length > 0 && (
                <div className="bg-[#c9a227]/10 rounded-lg p-4 mt-3">
                  <p className="text-sm font-semibold text-[#c9a227] mb-2">💡 Pro Tips:</p>
                  <ul className="space-y-1">
                    {step.tips.map((tip, tipIndex) => (
                      <li key={tipIndex} className="text-sm text-[#334155] flex items-start gap-2">
                        <span className="text-[#c9a227]">✓</span>
                        {tip}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Share Buttons Component
function ShareButtons({ title }: { title: string }) {
  const [copied, setCopied] = useState(false);
  
  // Get URL on client side only
  const url = typeof window !== 'undefined' ? window.location.href : '';

  const shareLinks = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodeURIComponent(url)}&text=${encodeURIComponent(title)}`,
    linkedin: `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(url)}&title=${encodeURIComponent(title)}`,
    email: `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(`Read this article: ${url}`)}`
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex items-center gap-3 flex-wrap">
      <span className="text-sm font-medium text-[#334155]">Share:</span>
      <a
        href={shareLinks.facebook}
        target="_blank"
        rel="noopener noreferrer"
        className="w-10 h-10 rounded-full bg-[#1877f2] text-white flex items-center justify-center hover:opacity-80 transition-opacity"
      >
        <Facebook className="w-5 h-5" />
      </a>
      <a
        href={shareLinks.twitter}
        target="_blank"
        rel="noopener noreferrer"
        className="w-10 h-10 rounded-full bg-[#1da1f2] text-white flex items-center justify-center hover:opacity-80 transition-opacity"
      >
        <Twitter className="w-5 h-5" />
      </a>
      <a
        href={shareLinks.linkedin}
        target="_blank"
        rel="noopener noreferrer"
        className="w-10 h-10 rounded-full bg-[#0077b5] text-white flex items-center justify-center hover:opacity-80 transition-opacity"
      >
        <Linkedin className="w-5 h-5" />
      </a>
      <a
        href={shareLinks.email}
        className="w-10 h-10 rounded-full bg-[#ea4335] text-white flex items-center justify-center hover:opacity-80 transition-opacity"
      >
        <Mail className="w-5 h-5" />
      </a>
      <button
        onClick={copyToClipboard}
        className="w-10 h-10 rounded-full bg-[#0d5c4b] text-white flex items-center justify-center hover:opacity-80 transition-opacity"
      >
        {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
      </button>
    </div>
  );
}

// Reading Progress Bar
function ReadingProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercent = (scrollTop / docHeight) * 100;
      setProgress(scrollPercent);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed top-0 left-0 right-0 h-1 bg-gray-200 z-[60]">
      <div
        className="h-full bg-gradient-to-r from-[#0d5c4b] to-[#c9a227] transition-all duration-150"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

// Format content with bold handling
function FormattedContent({ content }: { content: string }) {
  const paragraphs = content.split('\n\n');
  
  return (
    <>
      {paragraphs.map((paragraph, pIndex) => {
        // Handle bold text at start of paragraph
        const boldMatch = paragraph.match(/^\*\*([^*]+)\*\*:?/);
        if (boldMatch) {
          const boldText = boldMatch[1];
          const restText = paragraph.slice(boldMatch[0].length).trim();
          return (
            <div key={pIndex} className="mb-6">
              <h4 className="text-xl font-semibold text-[#0d5c4b] mb-2">{boldText}</h4>
              {restText && <p className="text-[#334155] leading-relaxed">{restText}</p>}
            </div>
          );
        }
        return (
          <p key={pIndex} className="text-[#334155] leading-relaxed mb-4">
            {paragraph}
          </p>
        );
      })}
    </>
  );
}

// Main Blog Post Page
export default function BlogPostPage() {
  const params = useParams();
  const slug = params.slug as string;
  
  const post = allBlogPosts.find(p => p.slug === slug);
  
  if (!post) {
    return (
      <div className="min-h-screen bg-[#fdfbf7] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-serif font-bold text-[#0d5c4b] mb-4">Post Not Found</h1>
          <p className="text-[#334155] mb-6">The blog post you&apos;re looking for doesn&apos;t exist.</p>
          <Link href="/#education">
            <Button className="bg-[#0d5c4b] text-white hover:bg-[#0d5c4b]/90">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Education Hub
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-[#fdfbf7]">
      <ReadingProgress />
      
      {/* Hero Section */}
      <header className="bg-gradient-to-br from-[#064e3b] via-[#0d5c4b] to-[#0d9488] text-white py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Breadcrumb */}
            <nav className="flex items-center gap-2 text-sm text-white/70 mb-6">
              <Link href="/#home" className="hover:text-white transition-colors">Home</Link>
              <ChevronRight className="w-4 h-4" />
              <Link href="/#education" className="hover:text-white transition-colors">Education Hub</Link>
              <ChevronRight className="w-4 h-4" />
              <span className="text-[#c9a227]">{post.category}</span>
            </nav>

            {/* Category Badge */}
            <div className="flex items-center gap-3 mb-4">
              <span className="text-4xl">{post.emoji}</span>
              <span className="px-4 py-1.5 bg-[#c9a227] text-[#0f172a] rounded-full text-sm font-semibold uppercase tracking-wider">
                {post.category}
              </span>
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-serif font-bold leading-tight mb-6">
              {post.title}
            </h1>

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-6 text-sm text-white/80">
              <div className="flex items-center gap-2">
                <User className="w-4 h-4" />
                <span>{post.author}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4" />
                <span>{new Date(post.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{post.readTime} read</span>
              </div>
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                <span>{post.wordCount.toLocaleString()} words</span>
              </div>
            </div>

            {/* Share Buttons */}
            <div className="mt-8">
              <ShareButtons title={post.title} />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-12">
            {/* Table of Contents - Sidebar */}
            <aside className="hidden lg:block lg:w-80 flex-shrink-0">
              <TableOfContents sections={post.sections} />
            </aside>

            {/* Article Content */}
            <article className="flex-grow max-w-4xl">
              {/* Introduction */}
              <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12 mb-8">
                <div className="prose prose-lg max-w-none">
                  {post.introduction.split('\n\n').map((paragraph, index) => (
                    <p key={index} className="text-[#334155] leading-relaxed mb-4 text-lg first-letter:text-4xl first-letter:font-serif first-letter:text-[#0d5c4b] first-letter:font-bold first-letter:mr-1">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </div>

              {/* Main Sections */}
              {post.sections.map((section, index) => (
                <section
                  key={index}
                  data-section={index}
                  className="bg-white rounded-2xl shadow-lg p-8 md:p-12 mb-8 scroll-mt-24"
                >
                  <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#0d5c4b] mb-6 pb-4 border-b-2 border-[#c9a227]/30">
                    {section.title}
                  </h2>
                  <div className="prose prose-lg max-w-none">
                    <FormattedContent content={section.content} />
                  </div>
                </section>
              ))}

              {/* Step by Step Guide */}
              <section className="mb-8">
                <StepByStepSection guide={post.stepByStepGuide} />
              </section>

              {/* FAQs */}
              <section className="bg-white rounded-2xl shadow-lg p-8 md:p-12 mb-8">
                <FAQSection faqs={post.faqs} />
              </section>

              {/* Conclusion */}
              <section className="bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] rounded-2xl shadow-lg p-8 md:p-12 text-white mb-8">
                <h2 className="text-2xl md:text-3xl font-serif font-bold mb-6 flex items-center gap-3">
                  <span className="text-3xl">✨</span>
                  Conclusion
                </h2>
                <div className="prose prose-lg max-w-none text-white/90">
                  {post.conclusion.split('\n\n').map((paragraph, index) => (
                    <p key={index} className="leading-relaxed mb-4">
                      {paragraph}
                    </p>
                  ))}
                </div>
              </section>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-between gap-4 mb-8 bg-white rounded-2xl shadow-lg p-6 no-print">
                <Link href="/#education">
                  <Button variant="outline" className="border-[#0d5c4b] text-[#0d5c4b] hover:bg-[#f0fdf4]">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Education Hub
                  </Button>
                </Link>
                <div className="flex items-center gap-3">
                  <Button onClick={handlePrint} variant="outline" className="border-[#0d5c4b] text-[#0d5c4b] hover:bg-[#f0fdf4]">
                    🖨️ Print Article
                  </Button>
                </div>
              </div>

              {/* Keywords/Tags */}
              <div className="bg-white rounded-2xl shadow-lg p-6 mb-8">
                <h3 className="font-semibold text-[#0d5c4b] mb-3">🏷️ Keywords:</h3>
                <div className="flex flex-wrap gap-2">
                  {post.keywords.map((keyword, index) => (
                    <span
                      key={index}
                      className="px-3 py-1 bg-[#f0fdf4] text-[#0d5c4b] rounded-full text-sm"
                    >
                      {keyword}
                    </span>
                  ))}
                </div>
              </div>

              {/* Share Section */}
              <div className="bg-white rounded-2xl shadow-lg p-6">
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div>
                    <h3 className="font-semibold text-[#0d5c4b] mb-1">Found this article helpful?</h3>
                    <p className="text-sm text-[#334155]">Share it with others who might benefit.</p>
                  </div>
                  <ShareButtons title={post.title} />
                </div>
              </div>
            </article>
          </div>
        </div>
      </main>

      {/* Related Posts */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl font-serif font-bold text-[#0d5c4b] mb-8 text-center">
            📚 Related Articles
          </h2>
          <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
            {post.relatedPosts.map((relatedId) => {
              const relatedPost = allBlogPosts.find(p => p.id === relatedId);
              if (!relatedPost) return null;
              return (
                <Link key={relatedId} href={`/blog/${relatedPost.slug}`}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer border border-gray-100">
                    <CardContent className="p-6">
                      <span className="text-2xl mb-3 block">{relatedPost.emoji}</span>
                      <span className="text-xs font-semibold text-[#c9a227] uppercase tracking-wider">
                        {relatedPost.category}
                      </span>
                      <h3 className="font-semibold text-[#0d5c4b] mt-2 line-clamp-2">
                        {relatedPost.title}
                      </h3>
                      <p className="text-sm text-[#334155] mt-2 line-clamp-2">
                        {relatedPost.excerpt}
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[#0f172a] text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <p className="text-gray-400">
            © {new Date().getFullYear()} Fife Islamic Centre - Noor-e-Madina Mosque. All rights reserved.
          </p>
        </div>
      </footer>

      {/* Print Styles */}
      <style jsx global>{`
        @media print {
          header, footer, aside, .no-print {
            display: none !important;
          }
          main {
            padding: 0 !important;
          }
          article {
            max-width: 100% !important;
          }
          .shadow-lg, .shadow-sm {
            box-shadow: none !important;
          }
          body {
            background: white !important;
          }
        }
      `}</style>
    </div>
  );
}
