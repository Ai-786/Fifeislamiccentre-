'use client';

import { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { 
  Menu, 
  X, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Users, 
  BookOpen, 
  Heart,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Printer,
  Download,
  ExternalLink,
  Moon,
  Sun,
  BookMarked,
  GraduationCap,
  HeartHandshake,
  Church,
  User,
  Scroll,
  Building,
  Star,
  Sparkles
} from 'lucide-react';
import { 
  namesOfAllah, 
  blogPosts, 
  categories,
  type BlogPost 
} from '@/lib/data/posts';
import {
  calculatePrayerTimes,
  getNextPrayer,
  getMonthlyPrayerTimes,
  getMonthName,
  getCountdown,
  getIslamicDate,
  getJamaatTimes,
  formatTime,
  formatTime12Hour,
  CALCULATION_METHODS,
  SCHOOLS_OF_THOUGHT,
  type CalculationMethodType,
  type SchoolOfThoughtType,
  type DailyPrayerTimes,
  type PrayerTimesResult,
  type CountdownTime
} from '@/lib/data/prayerTimes';
import { namesOfAllah as allNamesOfAllah } from '@/lib/data/names';

export default function Home() {
  // State management
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);
  const [activeCategory, setActiveCategory] = useState('all');
  const [visiblePosts, setVisiblePosts] = useState(12);
  
  // Prayer times state
  const [calculationMethod, setCalculationMethod] = useState<CalculationMethodType>('MWL');
  const [schoolOfThought, setSchoolOfThought] = useState<SchoolOfThoughtType>('Shafi');
  const [nextPrayer, setNextPrayer] = useState<{ name: string; time: Date } | null>(null);
  const [countdown, setCountdown] = useState<CountdownTime | null>(null);
  
  // Monthly timetable state
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth());
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  
  // Memoized prayer times calculation
  const prayerTimes = useMemo(() => {
    return calculatePrayerTimes(new Date(), calculationMethod, schoolOfThought);
  }, [calculationMethod, schoolOfThought]);
  
  // Memoized monthly timetable
  const monthlyTimes = useMemo(() => {
    return getMonthlyPrayerTimes(currentYear, currentMonth, calculationMethod, schoolOfThought);
  }, [currentYear, currentMonth, calculationMethod, schoolOfThought]);
  
  // Countdown timer
  useEffect(() => {
    const updateCountdown = () => {
      const now = new Date();
      const next = getNextPrayer(now, calculationMethod, schoolOfThought);
      setNextPrayer({ name: next.name, time: next.time });
      setCountdown(getCountdown(next.time, now));
    };
    
    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [calculationMethod, schoolOfThought]);
  
  // Scroll effects
  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      setShowBackToTop(window.scrollY > 500);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  // Intersection Observer for reveal animations
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('revealed');
          }
        });
      },
      { threshold: 0.1 }
    );
    
    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
  
  // Filter blog posts
  const filteredPosts = activeCategory === 'all' 
    ? blogPosts 
    : blogPosts.filter(post => post.category === activeCategory);
  
  // Month navigation
  const prevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };
  
  const nextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };
  
  // Print timetable
  const printTimetable = () => {
    window.print();
  };
  
  // Download timetable as CSV
  const downloadTimetable = () => {
    const headers = ['Date', 'Day', 'Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
    const rows = monthlyTimes.map(day => [
      `${day.day}/${currentMonth + 1}/${currentYear}`,
      day.dayName,
      day.fajr,
      day.sunrise,
      day.dhuhr,
      day.asr,
      day.maghrib,
      day.isha
    ]);
    
    const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `prayer-times-${getMonthName(currentMonth)}-${currentYear}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };
  
  // Get Islamic date
  const islamicDate = getIslamicDate(new Date());
  
  // Scroll to section
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };
  
  // Scroll to top
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  
  // Navigation links
  const navLinks = [
    { label: 'Home', id: 'hero' },
    { label: 'Prayer Times', id: 'prayer-times' },
    { label: 'About', id: 'about' },
    { label: 'Services', id: 'services' },
    { label: 'Education Hub', id: 'education' },
    { label: '99 Names', id: 'names' },
    { label: 'Donate', id: 'donate' },
    { label: 'Contact', id: 'contact' }
  ];
  
  // Get category icon
  const getCategoryIcon = (category: string) => {
    const icons: Record<string, string> = {
      'Quran': '📖',
      'Hadith': '📜',
      'Fiqh': '⚖️',
      'History': '🏛️',
      'Lifestyle': '🌟',
      'Family': '👨‍👩‍👧‍👦',
      'Comparative': '🤝'
    };
    return icons[category] || '📚';
  };
  
  // Prayer icons
  const prayerIcons: Record<string, React.ReactNode> = {
    'Fajr': <Moon className="w-5 h-5" />,
    'Sunrise': <Sun className="w-5 h-5" />,
    'Dhuhr': <Sun className="w-5 h-5" />,
    'Asr': <Sun className="w-5 h-5" />,
    'Maghrib': <Sun className="w-5 h-5" />,
    'Isha': <Moon className="w-5 h-5" />
  };
  
  // Jamaat times
  const jamaatTimes = prayerTimes ? getJamaatTimes(prayerTimes) : null;
  
  // Today's date string
  const today = new Date();
  const todayString = today.toLocaleDateString('en-GB', { 
    weekday: 'long', 
    day: 'numeric', 
    month: 'long', 
    year: 'numeric' 
  });

  return (
    <div className="min-h-screen bg-[#fdfbf7]">
      {/* Header */}
      <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'glass shadow-lg' : 'bg-transparent'
      }`}>
        {/* Top bar */}
        <div className="bg-gradient-to-r from-[#064e3b] to-[#0d5c4b] text-white py-2 text-sm">
          <div className="container mx-auto px-4 flex justify-between items-center">
            <span className="font-medium">Assalamu Alaikum</span>
            <span className="text-[#c9a227]">
              {islamicDate.day} {islamicDate.month} {islamicDate.year} AH
            </span>
          </div>
        </div>
        
        {/* Main header */}
        <div className={`${scrolled ? 'bg-white/95' : 'bg-white'} transition-colors duration-300`}>
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] flex items-center justify-center text-white">
                <Church className="w-7 h-7" />
              </div>
              <div>
                <h1 className="font-serif text-xl font-bold text-[#0d5c4b]">Fife Islamic Centre</h1>
                <p className="text-xs text-[#334155]">Noor-e-Madina Mosque</p>
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-6">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => scrollToSection(link.id)}
                  className="nav-link text-sm font-medium text-[#334155] hover:text-[#0d5c4b] transition-colors"
                >
                  {link.label}
                </button>
              ))}
              <Button 
                className="donate-btn"
                onClick={() => scrollToSection('donate')}
              >
                <Heart className="w-4 h-4 mr-2" />
                Support Us
              </Button>
            </nav>
            
            {/* Mobile Menu */}
            <div className="lg:hidden">
              <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <Menu className="w-6 h-6" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-80">
                  <div className="flex flex-col gap-4 pt-8">
                    {navLinks.map((link) => (
                      <button
                        key={link.id}
                        onClick={() => scrollToSection(link.id)}
                        className="text-left py-3 px-4 text-lg font-medium text-[#334155] hover:text-[#0d5c4b] hover:bg-[#f0fdf4] rounded-lg transition-colors"
                      >
                        {link.label}
                      </button>
                    ))}
                    <Button 
                      className="donate-btn mt-4"
                      onClick={() => scrollToSection('donate')}
                    >
                      <Heart className="w-4 h-4 mr-2" />
                      Support Us
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </header>
      
      {/* Hero Section */}
      <section id="hero" className="relative min-h-screen flex items-center gradient-hero islamic-pattern pt-32 pb-16">
        <div className="absolute inset-0 gradient-mesh opacity-50"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <div className="text-white reveal">
              <h1 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
                Welcome to<br />
                <span className="text-[#c9a227]">Noor-e-Madina Mosque</span>
              </h1>
              <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed">
                A place of worship, learning, and community. Serving the Muslim community of Glenrothes and Fife for over 15 years.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button 
                  size="lg"
                  className="bg-white text-[#0d5c4b] hover:bg-white/90 font-semibold"
                  onClick={() => scrollToSection('prayer-times')}
                >
                  <Clock className="w-5 h-5 mr-2" />
                  View Prayer Times
                </Button>
                <Button 
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10"
                  onClick={() => scrollToSection('about')}
                >
                  Learn More
                </Button>
              </div>
            </div>
            
            {/* Next Prayer Widget */}
            <div className="reveal stagger-2">
              <Card className="bg-white/10 backdrop-blur-lg border-white/20 text-white">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg font-medium text-white/80 flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Next Prayer
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-6">
                    <p className="text-sm text-white/70 mb-2">Coming up</p>
                    <h2 className="text-3xl font-serif font-bold text-[#c9a227] mb-2">
                      {nextPrayer?.name || 'Loading...'}
                    </h2>
                    <p className="text-lg text-white/90 mb-6">
                      {nextPrayer ? formatTime12Hour(nextPrayer.time) : '--:--'}
                    </p>
                    
                    {/* Countdown */}
                    {countdown && (
                      <div className="flex justify-center gap-3 mb-6">
                        <div className="countdown-digit">
                          <span className="text-3xl font-bold">{String(countdown.hours).padStart(2, '0')}</span>
                          <p className="text-xs text-white/70 mt-1">Hours</p>
                        </div>
                        <span className="text-3xl font-bold self-start mt-2">:</span>
                        <div className="countdown-digit">
                          <span className="text-3xl font-bold">{String(countdown.minutes).padStart(2, '0')}</span>
                          <p className="text-xs text-white/70 mt-1">Minutes</p>
                        </div>
                        <span className="text-3xl font-bold self-start mt-2">:</span>
                        <div className="countdown-digit">
                          <span className="text-3xl font-bold">{String(countdown.seconds).padStart(2, '0')}</span>
                          <p className="text-xs text-white/70 mt-1">Seconds</p>
                        </div>
                      </div>
                    )}
                    
                    <p className="text-sm text-white/60">{todayString}</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#fdfbf7] to-transparent"></div>
      </section>
      
      {/* Quick Stats Section */}
      <section className="py-16 bg-[#fdfbf7] relative -mt-8 z-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { number: '500+', label: 'Weekly Worshippers', icon: Users },
              { number: '15+', label: 'Years of Service', icon: Heart },
              { number: '60+', label: 'Educational Articles', icon: BookOpen },
              { number: '100+', label: 'Students Enrolled', icon: GraduationCap }
            ].map((stat, index) => (
              <div 
                key={index}
                className="reveal bg-white rounded-2xl p-6 text-center card-hover shadow-sm border border-gray-100"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] flex items-center justify-center text-white">
                  <stat.icon className="w-7 h-7" />
                </div>
                <h3 className="text-3xl font-bold text-[#0d5c4b] mb-1">{stat.number}</h3>
                <p className="text-sm text-[#334155]">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Prayer Times Section */}
      <section id="prayer-times" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 reveal">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#0d5c4b] mb-4">
              Prayer Times
            </h2>
            <div className="section-divider"></div>
            <p className="text-[#334155] max-w-2xl mx-auto">
              Accurate prayer times for Glenrothes, Fife. Coordinates: 56.1937°N, 3.1588°W
            </p>
          </div>
          
          {/* Settings Panel */}
          <div className="reveal bg-[#f0fdf4] rounded-2xl p-6 mb-8">
            <h3 className="font-semibold text-[#0d5c4b] mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              Prayer Time Settings
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-[#334155] mb-2 block">Calculation Method</label>
                <Select value={calculationMethod} onValueChange={(v) => setCalculationMethod(v as CalculationMethodType)}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CALCULATION_METHODS.map((method) => (
                      <SelectItem key={method.value} value={method.value}>
                        {method.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-sm font-medium text-[#334155] mb-2 block">School of Thought (Asr)</label>
                <Select value={schoolOfThought} onValueChange={(v) => setSchoolOfThought(v as SchoolOfThoughtType)}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {SCHOOLS_OF_THOUGHT.map((school) => (
                      <SelectItem key={school.value} value={school.value}>
                        {school.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          
          {/* Today's Prayer Cards */}
          <div className="grid md:grid-cols-5 gap-4 mb-8 reveal">
            {prayerTimes && ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].map((prayer) => {
              const time = prayerTimes[prayer.toLowerCase() as keyof PrayerTimesResult];
              const jamaatTime = jamaatTimes?.[prayer.toLowerCase() as keyof typeof jamaatTimes];
              const isNext = nextPrayer?.name === prayer;
              
              return (
                <Card 
                  key={prayer}
                  className={`text-center card-hover ${isNext ? 'ring-2 ring-[#c9a227] bg-gradient-to-b from-[#c9a227]/10 to-white' : ''}`}
                >
                  <CardContent className="pt-6">
                    <div className={`w-12 h-12 mx-auto mb-3 rounded-xl flex items-center justify-center ${
                      isNext ? 'bg-[#c9a227] text-white' : 'bg-[#0d5c4b]/10 text-[#0d5c4b]'
                    }`}>
                      {prayerIcons[prayer]}
                    </div>
                    <h3 className="font-semibold text-[#0d5c4b] mb-1">{prayer}</h3>
                    <p className="text-2xl font-bold text-[#0f172a]">{formatTime(time)}</p>
                    <p className="text-sm text-[#334155] mt-2">
                      <span className="text-[#c9a227]">Jamaat:</span> {jamaatTime}
                    </p>
                    {isNext && (
                      <span className="inline-block mt-3 px-3 py-1 bg-[#c9a227] text-white text-xs font-semibold rounded-full">
                        Next Prayer
                      </span>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
          
          {/* Jumuah Section */}
          <div className="reveal bg-gradient-to-r from-[#0d5c4b] to-[#0d9488] rounded-2xl p-8 text-white mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Church className="w-8 h-8 text-[#c9a227]" />
              <h3 className="font-serif text-2xl font-bold">Jumuah (Friday Prayer)</h3>
            </div>
            <div className="grid md:grid-cols-2 gap-6 max-w-xl mx-auto text-center">
              <div className="bg-white/10 rounded-xl p-4">
                <p className="text-white/70 text-sm mb-1">Khutbah</p>
                <p className="text-2xl font-bold">13:00</p>
              </div>
              <div className="bg-white/10 rounded-xl p-4">
                <p className="text-white/70 text-sm mb-1">Jamaat</p>
                <p className="text-2xl font-bold">13:30</p>
              </div>
            </div>
          </div>
          
          {/* Monthly Timetable */}
          <div className="reveal">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-serif text-2xl font-bold text-[#0d5c4b]">
                Monthly Timetable
              </h3>
              <div className="flex items-center gap-2 no-print">
                <Button variant="outline" size="sm" onClick={printTimetable}>
                  <Printer className="w-4 h-4 mr-2" />
                  Print
                </Button>
                <Button variant="outline" size="sm" onClick={downloadTimetable}>
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </div>
            </div>
            
            {/* Month Navigation */}
            <div className="flex items-center justify-center gap-4 mb-6">
              <Button variant="ghost" size="icon" onClick={prevMonth}>
                <ChevronLeft className="w-5 h-5" />
              </Button>
              <span className="font-semibold text-lg text-[#0d5c4b] min-w-[200px] text-center">
                {getMonthName(currentMonth)} {currentYear}
              </span>
              <Button variant="ghost" size="icon" onClick={nextMonth}>
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
            
            {/* Timetable */}
            <div className="overflow-x-auto rounded-xl border border-gray-200">
              <table className="w-full min-w-[600px]">
                <thead>
                  <tr className="bg-gradient-to-r from-[#0d5c4b] to-[#0d9488] text-white">
                    <th className="timetable-header">Date</th>
                    <th className="timetable-header">Fajr</th>
                    <th className="timetable-header">Sunrise</th>
                    <th className="timetable-header">Dhuhr</th>
                    <th className="timetable-header">Asr</th>
                    <th className="timetable-header">Maghrib</th>
                    <th className="timetable-header">Isha</th>
                  </tr>
                </thead>
                <tbody>
                  {monthlyTimes.map((day) => {
                    const isToday = 
                      day.day === today.getDate() && 
                      currentMonth === today.getMonth() && 
                      currentYear === today.getFullYear();
                    
                    return (
                      <tr 
                        key={day.day}
                        className={isToday ? 'timetable-current-day' : 'hover:bg-gray-50'}
                      >
                        <td className="timetable-cell font-medium">
                          {day.day} {day.dayName}
                          {isToday && (
                            <span className="ml-2 px-2 py-0.5 bg-[#c9a227] text-white text-xs rounded-full">
                              Today
                            </span>
                          )}
                        </td>
                        <td className="timetable-cell">{day.fajr}</td>
                        <td className="timetable-cell">{day.sunrise}</td>
                        <td className="timetable-cell">{day.dhuhr}</td>
                        <td className="timetable-cell">{day.asr}</td>
                        <td className="timetable-cell">{day.maghrib}</td>
                        <td className="timetable-cell">{day.isha}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>
      
      {/* About Section */}
      <section id="about" className="py-20 bg-[#fdfbf7]">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 reveal">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#0d5c4b] mb-4">
              About Fife Islamic Centre
            </h2>
            <div className="section-divider"></div>
          </div>
          
          {/* Mission and Address Cards */}
          <div className="grid md:grid-cols-2 gap-6 mb-12">
            <Card className="reveal gold-border card-hover">
              <CardHeader>
                <CardTitle className="text-[#0d5c4b] flex items-center gap-2">
                  <Star className="w-5 h-5 text-[#c9a227]" />
                  Our Mission
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-[#334155] leading-relaxed">
                  To serve the Muslim community of Glenrothes and surrounding areas by providing a welcoming space for worship, education, and community activities. We are committed to fostering understanding, promoting Islamic values, and building bridges with the wider community.
                </p>
              </CardContent>
            </Card>
            
            <Card className="reveal gold-border card-hover">
              <CardHeader>
                <CardTitle className="text-[#0d5c4b] flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-[#c9a227]" />
                  Our Location
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-[#334155] mb-4">
                  <strong>Fife Islamic Centre - Noor-e-Madina Mosque</strong><br />
                  786 Poplar Road<br />
                  Glenrothes, Fife KY7 4AA<br />
                  Scotland, United Kingdom
                </p>
                <Button asChild variant="outline" size="sm">
                  <a 
                    href="https://maps.google.com/?q=786+Poplar+Road+Glenrothes+Fife+KY7+4AA" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Get Directions
                  </a>
                </Button>
              </CardContent>
            </Card>
          </div>
          
          {/* Introduction */}
          <div className="reveal bg-white rounded-2xl p-8 shadow-sm mb-12">
            <h3 className="font-serif text-2xl font-bold text-[#0d5c4b] mb-4">
              Welcome to Fife Islamic Centre
            </h3>
            <p className="text-[#334155] leading-relaxed drop-cap mb-6">
              The Fife Islamic Centre, also known as Noor-e-Madina Mosque, has been a cornerstone of the Muslim community in Glenrothes and the wider Fife area for over 15 years. Our mosque serves as a spiritual sanctuary where Muslims can gather for daily prayers, seek knowledge, and strengthen their connection with Allah. We are dedicated to creating an inclusive environment that welcomes people of all backgrounds and levels of Islamic knowledge.
            </p>
            <p className="text-[#334155] leading-relaxed">
              Our centre offers a comprehensive range of services including daily congregational prayers, Quranic education for children and adults, Islamic lectures, youth programs, and community events. We also provide essential services such as Nikah (Islamic marriage ceremonies), funeral services, and counseling. Our doors are open to anyone seeking to learn about Islam or in need of spiritual guidance.
            </p>
          </div>
          
          {/* Five Pillars of Islam */}
          <div className="reveal mb-12">
            <h3 className="font-serif text-2xl font-bold text-[#0d5c4b] mb-6 text-center">
              The Five Pillars of Islam
            </h3>
            <div className="grid md:grid-cols-5 gap-4">
              {[
                { 
                  title: 'Shahada', 
                  arabic: 'الشهادة',
                  description: 'The declaration of faith: "There is no god but Allah, and Muhammad is His messenger." This is the foundation of Islamic belief.',
                  icon: BookMarked
                },
                { 
                  title: 'Salah', 
                  arabic: 'الصلاة',
                  description: 'The five daily prayers performed facing the Kaaba in Makkah. Prayer is the direct link between the worshipper and Allah.',
                  icon: Church
                },
                { 
                  title: 'Zakat', 
                  arabic: 'الزكاة',
                  description: 'The obligatory charity given to those in need, typically 2.5% of one\'s savings annually. It purifies wealth and helps the community.',
                  icon: Heart
                },
                { 
                  title: 'Sawm', 
                  arabic: 'الصوم',
                  description: 'Fasting during the month of Ramadan from dawn to sunset. It develops self-discipline, empathy, and spiritual awareness.',
                  icon: Moon
                },
                { 
                  title: 'Hajj', 
                  arabic: 'الحج',
                  description: 'The pilgrimage to Makkah, required once in a lifetime for those who are physically and financially able.',
                  icon: MapPin
                }
              ].map((pillar, index) => (
                <div 
                  key={index}
                  className="pillar-box text-center"
                >
                  <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] flex items-center justify-center text-white">
                    <pillar.icon className="w-6 h-6" />
                  </div>
                  <h4 className="font-semibold text-[#0d5c4b] mb-1">{pillar.title}</h4>
                  <p className="text-lg text-[#c9a227] font-serif mb-2">{pillar.arabic}</p>
                  <p className="text-xs text-[#334155] leading-relaxed">{pillar.description}</p>
                </div>
              ))}
            </div>
          </div>
          
          {/* Holy Quran Section */}
          <div className="reveal bg-gradient-to-r from-[#0d5c4b] to-[#0d9488] rounded-2xl p-8 text-white mb-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="font-serif text-2xl font-bold mb-4">
                  The Holy Quran
                </h3>
                <p className="text-white/90 leading-relaxed mb-4">
                  The Quran is the holy book of Islam, believed to be the word of Allah as revealed to Prophet Muhammad (PBUH) through the Angel Gabriel over a period of 23 years. It contains 114 chapters (Surahs) and serves as the primary source of guidance for Muslims worldwide.
                </p>
                <p className="text-white/90 leading-relaxed mb-4">
                  The Quran addresses all aspects of life, from matters of faith and worship to social justice, family life, and personal conduct. Its message of monotheism, moral guidance, and compassion has inspired billions throughout history.
                </p>
                <Button 
                  variant="outline" 
                  className="border-white text-white hover:bg-white/10"
                  onClick={() => scrollToSection('education')}
                >
                  Explore Quranic Studies
                </Button>
              </div>
              <div className="text-center">
                <div className="w-48 h-48 mx-auto rounded-full bg-white/10 flex items-center justify-center">
                  <BookOpen className="w-24 h-24 text-[#c9a227]" />
                </div>
                <p className="text-lg font-serif mt-4 text-[#c9a227]">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
                <p className="text-sm text-white/70 mt-2">In the name of Allah, the Most Gracious, the Most Merciful</p>
              </div>
            </div>
          </div>
          
          {/* Prophet Muhammad (PBUH) Biography */}
          <div className="reveal bg-white rounded-2xl p-8 shadow-sm mb-12">
            <h3 className="font-serif text-2xl font-bold text-[#0d5c4b] mb-4">
              Prophet Muhammad (Peace Be Upon Him)
            </h3>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <p className="text-[#334155] leading-relaxed mb-4">
                  Prophet Muhammad (PBUH) was born in Makkah in 570 CE. Known as "Al-Amin" (the Trustworthy) even before his prophethood, he received the first revelation at age 40 in the Cave of Hira. Over the next 23 years, he delivered the message of Islam, transforming Arabian society and establishing a model community based on justice, compassion, and devotion to Allah.
                </p>
                <p className="text-[#334155] leading-relaxed mb-4">
                  His life exemplifies the perfect balance between spiritual devotion and worldly responsibilities. He was a devoted husband, father, leader, and servant of Allah. His teachings and actions, recorded in the Hadith, continue to guide Muslims in every aspect of life.
                </p>
                <p className="text-[#334155] leading-relaxed">
                  The Prophet (PBUH) emphasized kindness, honesty, humility, and service to humanity. He said: "The best among you are those who have the best manners and character." His legacy of compassion and wisdom remains a beacon of guidance for all humanity.
                </p>
              </div>
              <div className="bg-[#f0fdf4] rounded-xl p-6">
                <h4 className="font-semibold text-[#0d5c4b] mb-3">Key Facts</h4>
                <ul className="space-y-2 text-sm text-[#334155]">
                  <li className="flex items-start gap-2">
                    <span className="text-[#c9a227]">•</span>
                    Born: 570 CE in Makkah
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#c9a227]">•</span>
                    First Revelation: 610 CE
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#c9a227]">•</span>
                    Migration to Madinah: 622 CE
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#c9a227]">•</span>
                    Conquest of Makkah: 630 CE
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-[#c9a227]">•</span>
                    Passed away: 632 CE
                  </li>
                </ul>
              </div>
            </div>
          </div>
          
          {/* Community Services */}
          <div className="reveal bg-white rounded-2xl p-8 shadow-sm mb-12">
            <h3 className="font-serif text-2xl font-bold text-[#0d5c4b] mb-4">
              Our Community Services
            </h3>
            <p className="text-[#334155] leading-relaxed mb-6">
              Fife Islamic Centre is deeply committed to serving the community through various outreach programs and services. We believe that a mosque should be more than just a place of worship—it should be a center of community life, education, and support. Our services are designed to meet the spiritual, educational, and social needs of our diverse community.
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              {[
                'Daily congregational prayers with Imam-led prayers',
                'Quran classes for children and adults',
                'Islamic marriage (Nikah) ceremonies',
                'Funeral services and Ghusl facilities',
                'Youth programs and activities',
                'Community hall for events',
                'Islamic counseling and guidance',
                'Interfaith dialogue and community outreach'
              ].map((service, index) => (
                <div key={index} className="flex items-center gap-2 text-[#334155]">
                  <Heart className="w-4 h-4 text-[#c9a227] flex-shrink-0" />
                  <span>{service}</span>
                </div>
              ))}
            </div>
          </div>
          
          {/* Seeking Knowledge */}
          <div className="reveal bg-gradient-to-br from-[#c9a227]/10 to-[#e6c656]/10 rounded-2xl p-8 gold-border">
            <h3 className="font-serif text-2xl font-bold text-[#0d5c4b] mb-4">
              The Importance of Seeking Knowledge
            </h3>
            <p className="text-[#334155] leading-relaxed mb-4">
              Islam places great emphasis on the pursuit of knowledge. The first word revealed in the Quran was "Read" (Iqra), highlighting the importance of learning. Prophet Muhammad (PBUH) said: "Seeking knowledge is an obligation upon every Muslim." This hadith underscores that education is not just encouraged but obligatory in Islam.
            </p>
            <p className="text-[#334155] leading-relaxed mb-4">
              At Fife Islamic Centre, we strive to provide opportunities for continuous learning through our educational programs, lectures, and resources. Whether you are new to Islam or seeking to deepen your understanding, we have something for everyone. Visit our <button onClick={() => scrollToSection('education')} className="text-[#0d5c4b] font-semibold hover:underline">Education Hub</button> to explore our collection of articles and resources.
            </p>
            <div className="flex items-center gap-4 mt-6">
              <Button 
                className="gradient-primary text-white"
                onClick={() => scrollToSection('education')}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Explore Education Hub
              </Button>
              <Button 
                variant="outline"
                onClick={() => scrollToSection('services')}
              >
                View Our Services
              </Button>
            </div>
          </div>
        </div>
      </section>
      
      {/* 99 Names of Allah Section */}
      <section id="names" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 reveal">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#0d5c4b] mb-4">
              The 99 Names of Allah
            </h2>
            <div className="section-divider"></div>
            <p className="text-[#334155] max-w-2xl mx-auto">
              "And to Allah belong the best names, so invoke Him by them." - Quran 7:180
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 reveal">
            {allNamesOfAllah.map((name) => (
              <div key={name.number} className="name-card">
                <div className="flex items-start gap-3">
                  <span className="flex-shrink-0 w-8 h-8 rounded-full bg-[#0d5c4b]/10 text-[#0d5c4b] flex items-center justify-center text-sm font-semibold">
                    {name.number}
                  </span>
                  <div>
                    <p className="text-xl font-serif text-[#c9a227] mb-1" dir="rtl">{name.arabic}</p>
                    <p className="font-semibold text-[#0d5c4b]">{name.transliteration}</p>
                    <p className="text-sm text-[#334155]">{name.meaning}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      
      {/* Services Section */}
      <section id="services" className="py-20 bg-[#fdfbf7]">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 reveal">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#0d5c4b] mb-4">
              Our Services
            </h2>
            <div className="section-divider"></div>
            <p className="text-[#334155] max-w-2xl mx-auto">
              Serving the spiritual and social needs of our community with dedication and compassion.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 reveal">
            {[
              {
                icon: Church,
                title: 'Daily Prayers',
                description: 'Five daily congregational prayers in a peaceful and spiritually uplifting environment. Join us for Fajr, Dhuhr, Asr, Maghrib, and Isha prayers.'
              },
              {
                icon: BookOpen,
                title: 'Quran Classes',
                description: 'Comprehensive Quranic education for all ages and skill levels. Learn Quran recitation with Tajweed, memorization, and understanding.'
              },
              {
                icon: HeartHandshake,
                title: 'Nikah Services',
                description: 'Islamic marriage ceremonies conducted according to Shariah. We provide marriage counseling and solemnization services.'
              },
              {
                icon: Heart,
                title: 'Funeral Services',
                description: 'Complete funeral services including Ghusl, shrouding, Janazah prayer, and burial arrangements. Support during difficult times.'
              },
              {
                icon: Users,
                title: 'Youth Programs',
                description: 'Engaging programs for young Muslims including sports, educational activities, and mentorship to build strong Islamic identity.'
              },
              {
                icon: Building,
                title: 'Community Hall',
                description: 'A multi-purpose hall available for community events, lectures, weddings, and social gatherings. A space for community bonding.'
              }
            ].map((service, index) => (
              <Card key={index} className="card-hover gold-border">
                <CardContent className="pt-6">
                  <div className="service-icon">
                    <service.icon className="w-7 h-7" />
                  </div>
                  <h3 className="font-semibold text-lg text-[#0d5c4b] mb-2">{service.title}</h3>
                  <p className="text-sm text-[#334155] leading-relaxed">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
      
      {/* Education Hub Section */}
      <section id="education" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 reveal">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#0d5c4b] mb-4">
              Education Hub
            </h2>
            <div className="section-divider"></div>
            <p className="text-[#334155] max-w-2xl mx-auto">
              Explore our collection of Islamic articles covering Quran, Hadith, Fiqh, and more.
            </p>
          </div>
          
          {/* Category Filters */}
          <div className="flex flex-wrap justify-center gap-2 mb-8 reveal">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={activeCategory === category.id ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  setActiveCategory(category.id);
                  setVisiblePosts(12);
                }}
                className={activeCategory === category.id ? 'gradient-primary text-white' : ''}
              >
                <span className="mr-1">{category.icon}</span>
                {category.label}
              </Button>
            ))}
          </div>
          
          {/* Blog Posts Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 reveal">
            {filteredPosts.slice(0, visiblePosts).map((post) => (
              <Link key={post.id} href={`/blog/${post.slug}`}>
                <Card className="card-hover h-full cursor-pointer">
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-2xl">{post.emoji}</span>
                      <span className="category-badge">
                        {post.category}
                      </span>
                      <span className="text-xs text-[#334155]">{post.readTime} read</span>
                    </div>
                    <h3 className="font-semibold text-lg text-[#0d5c4b] mb-2 line-clamp-2 hover:text-[#c9a227] transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-sm text-[#334155] leading-relaxed line-clamp-3 mb-4">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-[#334155]">{post.date}</span>
                      <span className="text-[#0d5c4b] text-sm font-medium hover:text-[#c9a227]">
                        Read More →
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
          
          {/* Load More Button */}
          {visiblePosts < filteredPosts.length && (
            <div className="text-center mt-8 reveal">
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => setVisiblePosts(prev => prev + 12)}
              >
                Load More Articles
              </Button>
            </div>
          )}
        </div>
      </section>
      
      {/* Donate Section */}
      <section id="donate" className="py-20 gradient-hero islamic-pattern text-white">
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-12 reveal">
            <h2 className="font-serif text-3xl md:text-4xl font-bold mb-4">
              Support Your Local Mosque
            </h2>
            <div className="section-divider bg-white/30"></div>
            <p className="text-white/90 max-w-2xl mx-auto">
              Your generous donations help us maintain our services and continue serving the community.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto reveal">
            {[
              {
                amount: 25,
                purpose: 'Support daily operations and utilities',
                impact: 'Helps cover electricity, water, and heating costs for the mosque'
              },
              {
                amount: 50,
                purpose: 'Fund educational programs',
                impact: 'Sponsors a student for Quran classes for one month'
              },
              {
                amount: 100,
                purpose: 'Community outreach initiatives',
                impact: 'Supports food banks, charity drives, and community events'
              }
            ].map((donation, index) => (
              <Card 
                key={index} 
                className="bg-white/10 backdrop-blur border-white/20 text-white card-hover cursor-pointer"
              >
                <CardContent className="pt-6 text-center">
                  <p className="text-4xl font-bold text-[#c9a227] mb-2">£{donation.amount}</p>
                  <h3 className="font-semibold mb-2">{donation.purpose}</h3>
                  <p className="text-sm text-white/70">{donation.impact}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="text-center mt-12 reveal">
            <p className="text-white/70 mb-4">
              For larger donations or bank transfer details, please contact us:
            </p>
            <p className="text-white mb-2">
              <strong>Email:</strong> info@fifeislamiccentre.co.uk
            </p>
            <p className="text-white">
              <strong>Phone:</strong> 01592 612960
            </p>
          </div>
        </div>
      </section>
      
      {/* Contact Section */}
      <section id="contact" className="py-20 bg-[#fdfbf7]">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 reveal">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-[#0d5c4b] mb-4">
              Contact Us
            </h2>
            <div className="section-divider"></div>
            <p className="text-[#334155] max-w-2xl mx-auto">
              We are here to serve you. Reach out to us for any questions or support.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-6 mb-12 reveal">
            <Card className="text-center card-hover gold-border">
              <CardContent className="pt-6">
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] flex items-center justify-center text-white">
                  <MapPin className="w-7 h-7" />
                </div>
                <h3 className="font-semibold text-[#0d5c4b] mb-2">Address</h3>
                <p className="text-sm text-[#334155]">
                  786 Poplar Road<br />
                  Glenrothes, Fife KY7 4AA<br />
                  Scotland, UK
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center card-hover gold-border">
              <CardContent className="pt-6">
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] flex items-center justify-center text-white">
                  <Phone className="w-7 h-7" />
                </div>
                <h3 className="font-semibold text-[#0d5c4b] mb-2">Phone</h3>
                <p className="text-sm text-[#334155]">
                  01592 612960<br />
                  01592 612970
                </p>
              </CardContent>
            </Card>
            
            <Card className="text-center card-hover gold-border">
              <CardContent className="pt-6">
                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-gradient-to-br from-[#0d5c4b] to-[#0d9488] flex items-center justify-center text-white">
                  <Mail className="w-7 h-7" />
                </div>
                <h3 className="font-semibold text-[#0d5c4b] mb-2">Email</h3>
                <p className="text-sm text-[#334155]">
                  info@fifeislamiccentre.co.uk
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Google Map */}
          <div className="reveal rounded-2xl overflow-hidden shadow-lg">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2230.2!2d-3.1588!3d56.1937!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48865d0!2sPoplar%20Rd%2C%20Glenrothes!5e0!3m2!1sen!2suk!4v1234567890"
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Fife Islamic Centre Location"
            />
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-[#064e3b] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* About */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
                  <Church className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-serif font-bold">Fife Islamic Centre</h3>
                  <p className="text-xs text-white/70">Noor-e-Madina Mosque</p>
                </div>
              </div>
              <p className="text-sm text-white/70 leading-relaxed">
                Serving the Muslim community of Glenrothes and Fife with daily prayers, Islamic education, and community services.
              </p>
            </div>
            
            {/* Quick Links */}
            <div>
              <h4 className="font-semibold mb-4 text-[#c9a227]">Quick Links</h4>
              <ul className="space-y-2">
                {navLinks.map((link) => (
                  <li key={link.id}>
                    <button 
                      onClick={() => scrollToSection(link.id)}
                      className="text-sm text-white/70 hover:text-white transition-colors"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
            
            {/* Services */}
            <div>
              <h4 className="font-semibold mb-4 text-[#c9a227]">Services</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>Daily Prayers</li>
                <li>Quran Classes</li>
                <li>Nikah Services</li>
                <li>Funeral Services</li>
                <li>Youth Programs</li>
                <li>Community Hall</li>
              </ul>
            </div>
            
            {/* Contact Info */}
            <div>
              <h4 className="font-semibold mb-4 text-[#c9a227]">Contact Info</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                  786 Poplar Road, Glenrothes, Fife KY7 4AA
                </li>
                <li className="flex items-center gap-2">
                  <Phone className="w-4 h-4 flex-shrink-0" />
                  01592 612960
                </li>
                <li className="flex items-center gap-2">
                  <Mail className="w-4 h-4 flex-shrink-0" />
                  info@fifeislamiccentre.co.uk
                </li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-white/10 pt-8 text-center">
            <p className="text-sm text-white/50">
              © {new Date().getFullYear()} Fife Islamic Centre - Noor-e-Madina Mosque. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
      
      {/* Back to Top Button */}
      {showBackToTop && (
        <button
          onClick={scrollToTop}
          className="back-to-top no-print"
          aria-label="Back to top"
        >
          <ChevronUp className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
