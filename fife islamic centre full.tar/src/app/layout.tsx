import type { Metadata } from "next";
import { Playfair_Display, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const playfairDisplay = Playfair_Display({
  variable: "--font-display",
  subsets: ["latin"],
  display: "swap",
});

const plusJakartaSans = Plus_Jakarta_Sans({
  variable: "--font-body",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Fife Islamic Centre - Noor-e-Madina Mosque | Glenrothes, Fife",
  description: "Welcome to Fife Islamic Centre - Noor-e-Madina Mosque. Serving the Muslim community of Glenrothes, Fife with daily prayers, Islamic education, Quran classes, and community services. Find accurate prayer times, learn about Islam, and connect with our vibrant community.",
  keywords: ["Fife Islamic Centre", "Noor-e-Madina Mosque", "Glenrothes Mosque", "Fife Mosque", "Prayer Times", "Islamic Centre", "Quran Classes", "Islamic Education", "Scotland Mosque", "Muslim Community Fife"],
  authors: [{ name: "Fife Islamic Centre" }],
  icons: {
    icon: "/favicon.ico",
  },
  openGraph: {
    title: "Fife Islamic Centre - Noor-e-Madina Mosque",
    description: "Serving the Muslim community of Glenrothes, Fife with daily prayers, Islamic education, and community services.",
    url: "https://fifeislamiccentre.co.uk",
    siteName: "Fife Islamic Centre",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Fife Islamic Centre - Noor-e-Madina Mosque",
    description: "Serving the Muslim community of Glenrothes, Fife with daily prayers, Islamic education, and community services.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${playfairDisplay.variable} ${plusJakartaSans.variable} antialiased`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
